
public class Vehicule {
	double positionX =0;
	double positionY =0;
	float vitesse = 0;
	double direction = 0;
	double deceMax = -5.0;
	String Couleur;
	String nom ;
	public Vehicule(double positionX, double positionY, String nom) {
		this.positionX = positionX;
		this.positionY = positionY;
		this.nom = nom;
	}
	public void accelerer(int dV) {
		this.vitesse += dV; 
	}
	
	public void tourner (double anR) {
		this.direction += anR;
	}
	
	public void deplacer(int duree) {
		float distance = this.vitesse * duree /1000;
		this.positionX += Math.cos(this.direction)*distance;
		this.positionY += Math.sin(this.direction)*distance;	
	}
	
	public String getNom() {
		return nom;
	}
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public void afficher() {
		System.out.println("position de "+this.nom+" = ("+this.positionX+","+this.positionY+")");
	}
	
	public void Gofast(double X, double Y) {
		double dist = Math.sqrt((this.positionX-X)*(this.positionX-X)+(this.positionY-Y)*(this.positionY-Y));
		double theta = Math.atan((Y-this.positionY)/(X-this.positionX));
		this.tourner(theta);
		this.positionX += Math.cos(this.direction)*dist;
		this.positionY += Math.sin(this.direction)*dist;
	
	}
	
	public double dist_to_stop(double obstacle,float stopX) {
		double xa = -(this.vitesse*this.vitesse)/(2*this.deceMax) + stopX;
		if (xa - obstacle > 0){
			System.out.println("Game Over");
		}
		else {
			System.out.println("Win");
		}
		return xa;
		
	}

}
