
public class jeu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehicule Voiture1 = new Vehicule(0.0,0.0,"BMW SERIE1");
		Vehicule Voiture2 = new Vehicule(1.0,0.0,"BMW SERIE2");
		Voiture1.afficher();
		Voiture2.afficher();
		
		//Voiture1.accelerer(1);
		//Voiture1.tourner(0.785);
		//Voiture1.deplacer(1000);
		
		Voiture1.Gofast(2, 2);
		
		Voiture2.vitesse = (float) 5.0;
		Voiture2.dist_to_stop(6,6);
		
		Voiture1.afficher();
	}

}
