public class Main {
    public static void main(String[] arg) {
        Matrix matrix;
        String response;
        do {
            if (Keyboard.readInteger("Pour une matrice carree, taper 1, sinon 0 : ") == 1) {
                int taille = Keyboard.readInteger("Indiquer le nombre de lignes : ");
                matrix = new Matrix(taille);
            } else {
                int nombreLignes = Keyboard.readInteger("Indiquer le nombre de lignes : ");
                int nombreColonnes = Keyboard.readInteger("Indiquer le nombre de colonnes : ");
                matrix = new Matrix(nombreLignes, nombreColonnes);
            }

            matrix.lectureClavier();
            System.out.println(matrix.toString());
            System.out.println("max = "+matrix.returnMaximum()+" min = "+matrix.returnMinimum() );
            System.out.println(matrix.transpose().toString());
            response = Keyboard.readString("Voulez-vous recommencer l'execution ? ");
        } while (response.toLowerCase().charAt(0) != 'n');
    }
}
