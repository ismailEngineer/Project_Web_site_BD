/**
 * classe pour la manipulation des matrices :
 *  - initialisation 
 *  - affichage 
 *  - lecture des matrices
 *  - saisie des matriices
 *  - Max et min des matrices
 *  - transpos� des matrices
 * @author E20C352K
 *
 */


public class Matrix {

    private int nombreLignes;

    private int nombreColonnes;

    private double[][] elements;

    public Matrix(int taille) {
        this(taille, taille);
    }

    public Matrix(int nombreLignes, int nombreColonnes) {
        this.nombreLignes = nombreLignes;
        this.nombreColonnes = nombreColonnes;
        elements = new double[nombreLignes][nombreColonnes];
    }

    public String toString() {
        String string = "La matrice est :\n";
        for (int i = 0; i < nombreLignes; i++)
        {
        	string += "\n| ";
            for (int j = 0; j < nombreColonnes; j++)
            {
                string = string + this.elements[i][j] +" ";
            }
            string += "|";
        }
        return string;
    }

    public void setElement(int i, int j, double valeur) {
        elements[i][j] = valeur;
    }

    public void lectureClavier() {
        for (int i = 0; i < nombreLignes; i++)
            for (int j = 0; j < nombreColonnes; j++)
                elements[i][j] = Keyboard.readDouble("Indiquer la valeur du terme[" + i + "]["
                                + j + "] : ");
    }
    public double returnMaximum() {
    	double max = this.elements[0][0];
    	 for (int i = 0; i < nombreLignes; i++)
             for (int j = 0; j < nombreColonnes; j++) {
            	 if (this.elements[i][j] > max) max = this.elements[i][j];
             }
         return (max);     
    }
    
    public double returnMinimum() {
    	double min = this.elements[0][0];
    	 for (int i = 0; i < nombreLignes; i++)
             for (int j = 0; j < nombreColonnes; j++) {
            	 if (this.elements[i][j] < min) min = this.elements[i][j];
             }
         return (min);     
    }
   public Matrix transpose() {
	   Matrix M = new Matrix(nombreColonnes,nombreLignes);
	   for (int i = 0; i < nombreLignes; i++)
       {
           for (int j = 0; j < nombreColonnes; j++)
           {
               M.elements[j][i] = this.elements[i][j];
         
           }
           
       }
       return M;
   }
   
}
