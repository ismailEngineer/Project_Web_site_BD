import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Keyboard {

    static private final BufferedReader in = new BufferedReader(
            new InputStreamReader(System.in));

    static public double readDouble(String question) {
        double readValue = 0.0;
        String readString = "";
        System.out.print(question);
        try {
            readString = in.readLine();
            readValue = Double.parseDouble(readString);
        } catch (IOException e) {
            System.out.print(e.getMessage() + "Incorrect double value");
        }
        return readValue;
    }
 
    static public int readInteger(String question) {
        return (int) readDouble(question);
    }

    static public String readString(String question) {
        String readString = "";
        System.out.print(question);
        try {
            readString = in.readLine();
        } catch (IOException e) {
            System.out.print(e.getMessage() + "Incorrect string value");
        }
        return readString;
    }

    static public void main(String[] args) {
        int readInteger = readInteger("Test integer->");
        double readDouble = readDouble("Test double->");
        String readString = readString("Test string->");
        System.out.println("int: " + readInteger + ", double: " + readDouble
                + ", string:" + readString);
    }
}
