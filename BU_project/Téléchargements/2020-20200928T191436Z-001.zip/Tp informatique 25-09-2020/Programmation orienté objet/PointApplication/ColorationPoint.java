/**
 * Un point coloré
 */
public class ColorationPoint {
	double x;
	double y;
	int couleur;
	public ColorationPoint() {
		this.x = 0;
		this.y = 0;
		this.couleur = 0;
	}

	public ColorationPoint(double x,double y, int couleurr) {
		this.x = x;
		this.y = y;
		this.couleur = couleurr;
	}
	
	public void quelsAttributs() {
		
		int choix=-1;
		int i=0;
		for(i=0;i<3;i++)
		{
		do {
		//System.out.println("preciser votre choix:  X->1, Y->2, Couleur->3 :");
		choix=Keyboard.readInteger("preciser votre choix:  X->1, Y->2, Couleur->3 :");
		}while(choix!=1 && choix!=2 && choix!=3);
		if(choix==1)
		{
			this.x = Keyboard.readDouble("Donner la valeur de X");
			
		}
		if(choix==2)
		{
			this.y = Keyboard.readDouble("Donner la valeur de Y");
		}
		if(choix==3)
		{
			this.couleur = Keyboard.readInteger("Donner la Couleur");
		}
		
		}
		
	}
	
	public void affiche() {
		System.out.println("Les attributs du point sont le ssuivants : x = "+this.x+" y = "+this.y+" couleur = "+this.couleur);
	}

}

