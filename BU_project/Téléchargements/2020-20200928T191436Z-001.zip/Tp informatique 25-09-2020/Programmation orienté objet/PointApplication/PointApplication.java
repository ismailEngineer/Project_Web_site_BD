public class PointApplication {
	
	public PointApplication() {
		String response;
		do {
			ColorationPoint colorationPoint1 = new ColorationPoint(3.8,4.6,255);
			colorationPoint1.affiche();
			ColorationPoint colorationPoint2 = new ColorationPoint();
			colorationPoint2.affiche();
			colorationPoint2.quelsAttributs();
			colorationPoint2.affiche();
			
			response = Keyboard.readString("Recommencer (o/n)?");
		} while((response.charAt(0) != 'n') && (response.charAt(0) != 'N'));
	}

	public static void main(String[] arg) {
		new PointApplication();	
	}	
}