function [L] = obs(Afixe,Toep,Oac)
    wf = 10; 
    Polesobs = [-1 -1 -1 -1 -1]'*wf ;
    polyobs = poly(Polesobs);
    polyl = poly(Afixe);
    L = inv(Toep*Oac)*[polyobs(6)-polyl(6); polyobs(5)-polyl(5); polyobs(4)-polyl(4); polyobs(3)-polyl(3); polyobs(2)-polyl(2)];
end